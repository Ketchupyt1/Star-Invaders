window.onload = function() {

  //Create a new game, with dimensions of 800 by 600
  var game = new Phaser.Game(800, 600, Phaser.AUTO, '', {preload: preload, create: create, update: update });

  //Global variables;
var player;
var controls;
var weapon;
var wallCheck = 0;
var speed = 5;
var invaders;
var invadersBullets;
var invadersShootCheck = 5000;
var shootChance = 20;
var score = 0;
var scoreText;
var lives = 3;
var livesText;
var bullet;
//var level 1;

  //Preload function, functionwe can load all of the assets that will be used
  function preload() {
game.load.image('player', 'assets/millenniumfalcon.png');
game.load.image('invader', 'assets/tiefighter.png');
game.load.image('bullet', 'assets/bullet.png');
game.load.image('rocket', 'assets/millenniumfalconfire.png');
game.load.image('space', 'assets/bg.png');
} //end of PRELOAD

  //Create function, where we can load all initial assets that will be used
  function create() {

    game.add.sprite(0,0, 'space');
// Add player to the game world
player = game.add.sprite(game.world.width/2, game.world.height - 150, 'player');
player.anchor.setTo(0.5,0.5);
game.physics.arcade.enable(player);
player.body.collideWorldBounds = true;

//Group all of the invaders together
invaders = game.add.group();
invaders.enableBody = true;

//Use a loob within a loop to create four rows of eight
for (var y = 0; y < 4; y++) {
  for (var x = 0; x < 8; x++) {
    var invader = invaders.create(x * 60, y * 50, 'invader');
    invader.body.velocity.x = 60;
  }
}

//Invader bullets
invadersBullets = game.add.group();
invadersBullets.enableBody = true;


//Weapon setup
weapon = game.add.weapon(5, 'rocket');
weapon.bulletKillType = Phaser.Weapon.KILL_WORLD_BOUNDS;
weapon.bulletSpeed = 300; //Pixels per second
weapon.fireRate = 500, //Milliseconds
weapon.bulletRotateToVelocity = true;
weapon.trackSprite(player); //Track the position of the player sprite

controls = game.input.keyboard.addKeys(
  {
    'shoot': Phaser.KeyCode.W,
    'left': Phaser.KeyCode.A,
    'right': Phaser.KeyCode.D
  }
);

scoreText = game.add.text(16, game.world.height-96, 'Score: '+ score, {fill:'yellow'});
livesText = game.add.text(16, game.world.height-66, 'Lives: '+ lives, {fill: 'yellow'});

} //end of CREATE

  //This function runs each and every frame
  function update() {

game.physics.arcade.collide(weapon.bullets, invaders, destroyInvader);
game.physics.arcade.overlap(player, invadersBullets, dead);

//Player movement
if (controls.left.isDown) {
  player.x -= speed;
} else if (controls.right.isDown) {
  player.x += speed;
}
//If player shoots
if (controls.shoot.isDown){
  weapon.fire ();
  console.log("Player has fired!");
}

if(game.time.now > wallCheck){
  //Check to see if any invader has hit an edge
  var wallHit = false;
  invaders.forEach(function(invader){
    if(invader.x < 0 || invader.x+invader.width > game.world.width) {
      wallHit =true;
      wallCheck = game.time.now + 100;
      return;
    }
  }, this);
}

//If an invader has it an edge, they all reverse direction and drop down
if(wallHit){
  invaders.forEach(function(invader){
    invader.body.velocity.x *= -1;
    invader.y += invader.height/2;
  }, this);
}

//Invader shooting
if(game.time.now > invadersShootCheck){
  invaders.forEach(function(invader){
    invaderShoot(invader);
  }, this);
  invadersShootCheck += 5000;
}

}  //end of UPDATE

function destroyInvader(rocket, invader) {
  //Increase the player's score and remove the invader
  rocket.kill();
  invader.kill();
  score += 10;
  //snd = game.add.audio('point');
  //snd.volume = 0.5;
  //snd.play();
  scoreText.text = 'Score: ' + score;
  invaders.remove(invader);
} //end of DESTROY INVADER

function invaderShoot(invader){
  if(game.rnd.integerInRange(0, 100)< shootChance){
    badBullet = invadersBullets.create(invader.x, invader.y, 'bullet');
    badBullet.body.velocity.y = 50;

  }
} //end of INVADER SHOOT

function dead(player, bullet){
  bullet.kill();
  player.x = game.world.width/2;
  lives--;
  livesText.text = 'Lives: ' + lives;
  if(lives < 1) {
    gameOver();
  }
  console.log('here'); //fix enemy fire
} //end of DEAD

function gameOver () {
  gg = game.add.sprite(game.world.width/2, game.world.height/2, 'gameover' );
  gg.anchor.setTo(0.5,0.5);
  game.paused = true;
} //end of GAMEOVER

//function level() {
  //if score = 320 {
    //level = level + 1;
  //}

  //if (level = 1) {
    //shootChance = 5
  //}

    //(else if level = 2) {
      //shootChance = 10;
    //}

    //else if ()
//} //end of LEVEL

};
